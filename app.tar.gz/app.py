# swim fit india
import flet
from flet import (
    Page,
    # WEB_BROWSER,
    FLET_APP,
    Container,
    alignment,
    Text,
    Column,
    Row,
    Image,
    ImageFit,
    ImageRepeat,
    MainAxisAlignment,
)


def main(page: Page):
    """
    Entry Point
    """
    print('Entry Point of the App- info')
    page.bgcolor = '#F0F2FA'
    page.window_maximized = True
    # page.window_maximizable = False
    # page.window_skip_task_bar = False

    page.padding = 0

    page.title = "Swim Fit India"

    page.add(
        Column([
            Row([
                Container(
                    alignment=alignment.center,
                    expand=True,
                    height=40
                )
            ]),
            Row([
                Container(
                    alignment=alignment.center,
                    content=Image(
                        src=f"/files.png",
                        width=220,
                        height=100,
                        fit=ImageFit.CONTAIN,
                        repeat=ImageRepeat.NO_REPEAT,
                    ),
                    # expand=True,
                ),
                Container(
                    alignment=alignment.center,
                    content=Image(
                        src=f"/line_of_code.png",
                        width=220,
                        height=100,
                        fit=ImageFit.CONTAIN,
                        repeat=ImageRepeat.NO_REPEAT,
                    ),
                    # expand=True,
                ), Container(
                    alignment=alignment.center,
                    content=Image(
                        src=f"/identified_objects.png",
                        width=220,
                        height=100,
                        fit=ImageFit.CONTAIN,
                        repeat=ImageRepeat.NO_REPEAT,
                    ),
                    # expand=True,
                ),
                Container(
                    alignment=alignment.center,
                    content=Image(
                        src=f"/conversion_rate.png",
                        width=220,
                        height=100,
                        fit=ImageFit.CONTAIN,
                        repeat=ImageRepeat.NO_REPEAT,
                    ),
                    # expand=True,
                ),
            ],
                alignment=MainAxisAlignment.SPACE_EVENLY
            ),
            Row([
                Container(
                    alignment=alignment.center,
                    expand=True,
                    height=40
                )
            ]),
            Row([
                Container(
                    alignment=alignment.center,
                    expand=True,
                    height=40
                )
            ]),
            Row([
                Container(
                    alignment=alignment.center,
                    expand=True,
                    content=Text('Hello World aa gaya!', size=35),
                ),
            ]),

        ])
    )

    page.update()


flet.app(target=main, assets_dir="assets", view=FLET_APP)
