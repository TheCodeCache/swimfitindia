# swim fit india
import flet
from flet import (
    Page,
    # WEB_BROWSER,
    FLET_APP,
    Container,
    alignment,
    Text,
    Column,
    Row,
    Image,
    ImageFit,
    ImageRepeat,
    MainAxisAlignment,
)


def main(page: Page):
    """
    Entry Point
    """
    print('Entry Point of the App- info')
    page.bgcolor = '#F0F2FA'
    page.window_maximized = True
    # page.window_maximizable = False
    # page.window_skip_task_bar = False

    page.padding = 10

    page.title = "Swimfit"

    page.add(
        Column([
            Row([
                Container(
                    alignment=alignment.center,
                    expand=True,
                    height=40
                )
            ]),
            Row([
                Container(
                    alignment=alignment.top_left,
                    content=Image(
                        src=f"/swimfit_logo.png",
                        width=220,
                        height=100,
                        fit=ImageFit.CONTAIN,
                        repeat=ImageRepeat.NO_REPEAT,
                    ),
                    # expand=True,
                ),
                Container(
                    alignment=alignment.center,
                    expand=True,
                    content=Text('Welcome to Swimfit, Enjoy swimming!', size=35),
                ),
            ],
                alignment=MainAxisAlignment.CENTER
            ),
            Row([
                Container(
                    alignment=alignment.center,
                    expand=True,
                    height=20
                )
            ]),
            Row([
                Container(
                    alignment=alignment.center,
                    content=Image(
                        src=f"/collage.jpeg",
                        width=1400,
                        height=340,
                        fit=ImageFit.CONTAIN,
                        repeat=ImageRepeat.NO_REPEAT,
                    ),
                    expand=True,
                ),
            ]),

        ])
    )

    page.update()


flet.app(target=main, assets_dir="assets", view=FLET_APP)
